/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   calc_bf.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hawild <hawild@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/05/16 18:35:19 by hawild            #+#    #+#             */
/*   Updated: 2024/05/16 20:43:17 by hawild           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

//#include "../include/push_swap.h"
# include <stddef.h>
# include <stdio.h>
# include <stdlib.h>
# include <string.h>
# include <unistd.h>

typedef struct s_list 
{
    int value;
    int index;
    struct s_list *next;
}            t_list;


typedef struct s_list_bf 
{
    // int bf_current;
    // int nbr_current;
	// int	moves_total_current;
    // int bf_moves_to_top;
    // int nbr_moves_to_top;
	// int bf_final;
	// int nbr_final;
    // int moves_total_final;
	// int	flag;
    int bf_current;
	int	bf_final;
	int index_a;
	int	index_b;
	int	nbr_b;
	int	costs_current;
	int	costs_final;
    struct s_list_bf *next;
}            t_list_bf;

		// if (bf->flag == 1)
		// {
		// 	bf->bf_final = bf->bf_current;
		// 	bf->flag = 0;
		// 	head_a = head_a->next;
		// 	bf->bf_current = (head_a->value - nbr_b);
		// }

int	calculate_bf(t_list **stack_a, t_list **stack_b, t_list_bf *bf)
{
	t_list_bf *bf;
	t_list	*head_a;
	float	lst_size;
	int i;

	bf = NULL;
	head_a = *stack_a;
	bf->bf_final = (head_a->value - bf->nbr_b);
	head_a = head_a->next;
	lst_size = ft_lstsize(*stack_a);
	i = 0;
	while (i <= lst_size)
	{
		bf->bf_current = (head_a->value - bf->nbr_b);
		if (bf->bf_current > 0 && bf->bf_current < bf->bf_final)
		{
			bf->bf_final = bf->bf_current;
			bf->index_a = i;
		}
		head_a = head_a->next;
		i++;;
	}
	return (bf->bf_final);
}

int	costs(t_list **stack_a, t_list **stack_b, t_list *bf)
{
	float lst_size_a;
	float	lst_size_b;

	lst_size_a = ft_lstsize(*stack_a);
	lst_size_b = ft_lstsize(*stack_b);
	if ((int)lst_size_a % 2 == 0)
	{
		
	}
}


int	best_friend(t_list **stack_a, t_list **stack_b)
{
	// int bf_current;
	// int	bf_final;
	// int *index_a;
	// int	*index_b;
	int i;
	// int	*nbr_b;
	// int	costs_current;
	// int	costs_final;
	t_list *head_b;
    t_list_bf *bf;

    bf = malloc(sizeof(t_list_bf));
    if (!bf)
        return (NULL);
    bf = NULL;
	head_b = *stack_b;
	bf->nbr_b = head_b->value;
	bf->bf_final = calculate_bf(stack_a, stack_b, bf);
	bf->costs_final = costs(stack_a, stack_b, bf);
	head_b = head_b->next;
	i = 0;
	while (head_b != NULL)
	{
		bf->nbr_b = head_b->value;
		bf->bf_current = calculate_bf(stack_a, stack_b, bf);
		if (); // calculate costs and compare current and final / set index_b
		head_b = head_b->next;
		i++;
	}
}

int main_algorithm(t_list **stack_a, t_list **stack_b)
{
    int i;
	t_list *temp_stack;
    
	temp_stack = NULL;
    i = sort_till_5_in_A(stack_a, stack_b);
	printf("stack after sort till 5\n");
	printf("stack a : \n");
	print_list(*stack_a);
	printf("stack b : \n");
	print_list(*stack_b);
	printf("now comes sort_5:\n");
    i = sort_5(stack_a, &temp_stack);
	free(temp_stack);
	return (i);
}